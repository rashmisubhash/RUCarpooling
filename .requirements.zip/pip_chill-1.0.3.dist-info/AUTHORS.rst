=======
Credits
=======

Development Lead
----------------

* Ricardo Bánffy <rbanffy@gmail.com>

Contributors
------------

* Kevin Paulson https://github.com/kjwpaulson
* Luke Skibinski https://github.com/lsh-0
* Piotr Surowiec https://github.com/Agrendalath
