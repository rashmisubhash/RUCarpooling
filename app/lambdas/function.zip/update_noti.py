import json
import boto3

dynamodb = boto3.resource("dynamodb")
notifications_table = dynamodb.Table("RUNotifications")

def lambda_handler(event, context):
    """Marks a notification as read."""
    try:
        body = json.loads(event["body"])
        notification_id = body.get("notification_id")

        if not notification_id:
            return {"statusCode": 400, "body": json.dumps({"error": "Missing notification_id"})}

        # ✅ Step 1: Update notification status in DynamoDB
        notifications_table.update_item(
            Key={"notification_id": notification_id},
            UpdateExpression="SET #s = :new_status",
            ExpressionAttributeNames={"#s": "notification_status"},
            ExpressionAttributeValues={":new_status": "read"}
        )

        return {"statusCode": 200, "body": json.dumps({"message": "Notification marked as read"})}

    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
    
# zip function.zip update_noti.py
# aws lambda update-function-code \
#     --function-name RUUpdateNotificationStatusHandler \
#     --zip-file fileb://function.zip \
#     --region us-east-1